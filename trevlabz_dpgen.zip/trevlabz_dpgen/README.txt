1. Trevor LaBanz - trevlabz

2. ECE574A

3. dpgen converts a behavioral netlist specification into a synthesizable verilog datapath implementation. Additionally the critical path is reported of the datapath. If an error occurs, an error message will be printed as well as a temp.txt file to help pinpoint where the error occured.

4. Contributions:
	-Trevor 95%
	-Internet 5%
